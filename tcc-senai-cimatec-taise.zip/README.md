# Modelo Senai Cimatec em LaTex
Modelo mínimo de TCC no formato do Senai Cimatec baseado no pacote ABNTEX2 e no projeto https://github.com/correialc/tcctex.
